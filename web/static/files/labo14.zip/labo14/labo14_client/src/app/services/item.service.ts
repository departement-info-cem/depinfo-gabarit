import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Item } from '../models/item';
import { lastValueFrom } from 'rxjs';

const domain = "https://localhost:LE PORT DE VOTRE SERVEUR";

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(public http : HttpClient) { }

  // ▄▄▄▄▄▄▄▄▄▄▄▄
  //    GetAll
  // ▀▀▀▀▀▀▀▀▀▀▀▀
  async getAll() : Promise<Item[]>{

    return [];

  }

  // ▄▄▄▄▄▄▄▄▄▄▄▄
  //      Get
  // ▀▀▀▀▀▀▀▀▀▀▀▀
  async get(id : number) : Promise<Item>{

    return new Item(0, "", 0);

  }

  // ▄▄▄▄▄▄▄▄▄▄▄▄
  //     Post
  // ▀▀▀▀▀▀▀▀▀▀▀▀
  async post(name : string, value : number) : Promise<void>{



  }

  // ▄▄▄▄▄▄▄▄▄▄▄▄
  //    Delete
  // ▀▀▀▀▀▀▀▀▀▀▀▀
  async delete(id : number) : Promise<void>{



  }

  // ▄▄▄▄▄▄▄▄▄▄▄▄
  //     Put
  // ▀▀▀▀▀▀▀▀▀▀▀▀
  async put(id : number, name : string, value : number) : Promise<void>{



  }

}
