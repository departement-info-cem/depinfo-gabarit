export class Artist{
    constructor(public id : string, public name : string, public imageUrl : string){}
}