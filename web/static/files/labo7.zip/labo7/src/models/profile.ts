export class Profile{
    constructor(public name : string, public age : number, public money : number){}
  }
  