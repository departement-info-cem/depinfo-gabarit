import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ChannelsComponent } from './channels/channels.component';

export const routes: Routes = [
    {path:"", redirectTo:"/chat", pathMatch:"full"},
    {path:"chat", component:ChannelsComponent},
    {path:"login", component:LoginComponent}
];
