export class Reaction{
    constructor(
        public id : number,
        public quantity : number,
        public isToggled : boolean
        ){}
}