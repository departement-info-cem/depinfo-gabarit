import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { Dinosaur } from '../models/dinosaur';
import { Zookeeper } from '../models/zookeeper';

const domain = "https://localhost:7298/";

@Injectable({
  providedIn: 'root'
})
export class DinosaurService {

  constructor(public http : HttpClient) { }

  async postDinosaur(name : string, specie : string, id : number) : Promise<Dinosaur>{

    // À compléter

    // À retirer
    return new Dinosaur(0, "Betty", "caniche",  [], new Zookeeper(0, "Cassandra"));

  }

  async getDinosaurs() : Promise<Dinosaur[]>{

    let x = await lastValueFrom(this.http.get<Dinosaur[]>(domain + "api/Dinosaurs/GetDinosaur"));
    console.log(x);
    return x;

  }

  async deleteDinosaur(id : number){

    // À compléter

  }

  async postZookeeper(name : string) : Promise<Zookeeper>{

    // À compléter

    // À retirer
    return new Zookeeper(0, "Omar");

  }

  async getZookeepers() : Promise<Zookeeper[]>{

    let x = await lastValueFrom(this.http.get<any>(domain + "api/Zookeepers/GetZookeeper"));
    console.log(x);
    return x;

  }

  async deleteZookeeper(id : number){

    // À compléter

  }

  async postIncident(description : string, nbCasualties : number, ids : number[]) : Promise<void>{

    // À compléter

  }

}
