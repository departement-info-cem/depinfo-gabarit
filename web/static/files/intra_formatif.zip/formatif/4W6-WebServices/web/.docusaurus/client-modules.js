export default [
  require("C:\\Users\\maxime.pelletier\\Desktop\\formatif\\4W6-WebServices\\web\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\maxime.pelletier\\Desktop\\formatif\\4W6-WebServices\\web\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\maxime.pelletier\\Desktop\\formatif\\4W6-WebServices\\web\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\maxime.pelletier\\Desktop\\formatif\\4W6-WebServices\\web\\src\\css\\custom.css"),
];
