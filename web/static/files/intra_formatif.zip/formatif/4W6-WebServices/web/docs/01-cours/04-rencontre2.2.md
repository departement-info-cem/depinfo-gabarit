# Cours 4 - TP1 (5%)
 
Cette période est entièrement consacrée au [TP1](/tp/tp1).