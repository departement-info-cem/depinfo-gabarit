export class Line {
  code: string;
  lineNumber: number;

  toString(): string {
    return this.code;
  }
}
