import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { VideoGame } from './models/videogame';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  // Servira plus tard
  videoGames : VideoGame[] = [];

}
