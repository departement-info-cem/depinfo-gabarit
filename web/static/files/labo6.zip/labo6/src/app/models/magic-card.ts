export class MagicCard {

    constructor(
        public name: string,
        public manaCost: string,
        public imageUrl: string,
        public type: string
    ) { }

}