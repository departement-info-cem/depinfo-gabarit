export class Song{

    constructor(
        public name : string,
        public artist : string,
        public duration : number
    ){}

}