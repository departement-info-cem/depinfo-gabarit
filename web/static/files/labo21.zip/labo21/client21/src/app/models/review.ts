export class Review{
    constructor(
        public id : number,
        public text : string,
        public author : string
    ){}
}