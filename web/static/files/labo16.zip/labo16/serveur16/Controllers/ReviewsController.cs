﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using serveur16.Data;
using serveur16.Models;
using serveur16.Models.DTOs;

namespace serveur16.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ReviewsController : ControllerBase
    {
        private readonly serveur16Context _context;
        private readonly UserManager<User> _userManager;

        public ReviewsController(serveur16Context context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<ActionResult/*<IEnumerable<ReviewDisplayDTO>>*/> GetReview()
        {
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> EditReview(int id/*, ReviewDTO reviewDTO*/)
        {
            return NoContent();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpvoteReview(int id)
        {
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Review>> PostReview(/*ReviewDTO reviewDTO*/)
        {
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReview(int id)
        {
            return NoContent();
        }
    }
}
