import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { Review } from '../models/review';

const domain = "https://localhost:7013/";

@Injectable({
  providedIn: 'root'
})
export class GameReviewService {

  constructor(public http : HttpClient) { }

  // Si une des fonctions ci-dessous n'a pas de RETURN actuellement, c'est que vous n'aurez pas à en mettre.

  async register(username : string, email : string, password : string, passwordConfirm : string){



  }

  async login(username : string, password : string){



  }

  async getReviews(){

    // À remplacer
    return [];

  }

  async postReview(text : string, game : string){

    // À remplacer
    return new Review(1, "Allo", "Ça va ?", "Bye", 0);

  }

  async deleteReview(id : number){



  }

  async editReview(id : number, text : string){



  }

  async upvoteReview(id : number){



  }

}
