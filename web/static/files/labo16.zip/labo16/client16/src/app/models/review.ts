export class Review{

    constructor(
        public id : number,
        public text : string,
        public game : string,
        public author : string,
        public upvotes : number
    ){}

}